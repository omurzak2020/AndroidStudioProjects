package com.suchi.flipcardanimationlist.flip;

public class EventData {
    int position;
    boolean isFront;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }


    public boolean isFront() {
        return isFront;
    }

    public void setFront(boolean front) {
        isFront = front;
    }

}
