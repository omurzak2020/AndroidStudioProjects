package com.example.quizview.geograpy

import android.view.View

interface OnClickAnAnswer {

     fun onClickButton()
     fun onClickSecondButton()
     fun onClickThirdButton()
     fun onClickForthButton()

}