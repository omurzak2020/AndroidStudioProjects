package com.example.quizview.geograpy

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.fragment.findNavController
import com.example.quizview.R
import com.example.quizview.databinding.FragmentGeographyBinding

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class GeographyFragment : Fragment(), OnClickAnAnswer {


    private val goeModel: GeigraphyViewModel by lazy {
        GeigraphyViewModel()
    }

    var binding: FragmentGeographyBinding? = null


    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_geography, container, false)
        binding?.geogViewModel = goeModel
        binding?.itself = this
         goeModel.onClickAnAnswer = this



        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding?.btnSkip?.setOnClickListener {
            navigateToOther(R.id.action_geographyFragment_to_quizTrueFalseFragment)
        }
    }

    //method to navigate
    fun navigateToOther(destId: Int) {
        findNavController().navigate(destId)
    }


    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            GeographyFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    override fun onClickButton() {

        binding?.mainQuation?.text = binding?.txtFirstAnswer?.text
        Log.e("TAG", "onClickButton: fist btn clicked ")

    }

    override fun onClickSecondButton() {
        binding?.mainQuation?.text = binding?.txtSecondAnswer?.text
    }

    override fun onClickThirdButton() {
        binding?.mainQuation?.text = binding?.txtThirdAnswer?.text
    }

    override fun onClickForthButton() {
        binding?.mainQuation?.text = binding?.txtForthAnswer?.text
    }
}

