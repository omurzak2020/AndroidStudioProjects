package com.example.quizview.geograpy


import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel
import com.example.quizview.databinding.FragmentGeographyBinding


class GeigraphyViewModel : ViewModel() {


    var onClickAnAnswer: OnClickAnAnswer? = null
    var result: ObservableField<String> = ObservableField()


    fun onClick() {
        onClickAnAnswer?.onClickButton()
    }

    fun onClickSecond() {
        onClickAnAnswer?.onClickSecondButton()
    }

    fun onClickThird() {
        onClickAnAnswer?.onClickThirdButton()
    }

    fun onClickFourth() {
        onClickAnAnswer?.onClickForthButton()
    }


}